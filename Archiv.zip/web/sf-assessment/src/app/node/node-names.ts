export const nodeNames: { [key: string]: string } = {
  PromptNode: 'prompt',
};
