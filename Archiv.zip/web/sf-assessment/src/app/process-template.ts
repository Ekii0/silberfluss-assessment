import { ProcessNode } from "./parser/types";

export const nodes: ProcessNode[] = [];